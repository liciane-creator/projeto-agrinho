function setup() {
  createCanvas(400, 400);
}
let carrinho; // Variável para o objeto carrinho
let estadoJogo = 'campo'; // 'campo', 'transicao', 'cidade'

// Arrays para armazenar as árvores e prédios
let arvores = [];
let predios = [];

// Array para as partículas de fumaça
let fumacaParticulas = [];

function setup() {
  createCanvas(800, 400); // Cria a tela
  carrinho = new Carrinho(50, height / 2); // Inicia o carrinho no campo

  // Crie algumas árvores no lado esquerdo (campo)
  for (let i = 0; i < 5; i++) {
    arvores.push(new Arvore(random(50, width / 2 - 50), random(height * 0.6, height - 50)));
  }

  // Crie alguns prédios no lado direito (cidade)
  for (let i = 0; i < 7; i++) {
    predios.push(new Predio(random(width / 2 + 50, width - 50), random(height * 0.4, height - 100)));
  }
}

function draw() {
  background(220); // Cor de fundo padrão

  // Desenha o gradiente de campo para cidade
  desenhaFundo();

  // Desenha as árvores
  for (let arvore of arvores) {
    arvore.display();
  }

  // Desenha os prédios
  for (let predio of predios) {
    predio.display();
  }

  // Lógica da Fumaça: Criar novas partículas e gerenciar as existentes
  // Adiciona uma nova partícula de fumaça a cada 5 frames no lado da cidade
  if (frameCount % 5 === 0) {
    let xFumaca = random(width / 2 + 30, width - 30); // Posição X na cidade
    let yFumaca = random(height * 0.2, height * 0.8); // Posição Y variável
    fumacaParticulas.push(new ParticulaFumaca(xFumaca, yFumaca));
  }

  // Atualiza e exibe as partículas de fumaça
  for (let i = fumacaParticulas.length - 1; i >= 0; i--) {
    fumacaParticulas[i].update();
    fumacaParticulas[i].display();
    if (fumacaParticulas[i].isFinished()) {
      fumacaParticulas.splice(i, 1); // Remove partículas que terminaram sua vida útil
    }
  }

  // Atualiza e desenha o carrinho
  carrinho.update();
  carrinho.display();

  // Lógica para os obstáculos e interações (será adicionada depois)
}

// --- CLASSE CARRINHO (SEM MUDANÇAS AQUI NESTE TRECHO) ---
class Carrinho {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.largura = 50;
    this.altura = 30;
    this.corCorpo = color(150, 100, 50); // Cor inicial do corpo do carrinho (campo)
    this.corRodas = color(50); // Cor das rodas
  }

  update() {
    this.x = mouseX;
    this.y = mouseY;

    if (this.x < width / 2) {
      this.corCorpo = color(150, 100, 50); // Tom de madeira/terra
    } else {
      this.corCorpo = color(120, 120, 120); // Tom de cinza metálico
    }

    this.x = constrain(this.x, 0, width - this.largura);
    this.y = constrain(this.y, 0, height - this.altura);
  }

  display() {
    fill(this.corCorpo);
    rect(this.x, this.y, this.largura, this.altura);

    fill(this.corRodas);
    ellipse(this.x + this.largura * 0.25, this.y + this.altura, 20, 20); // Roda dianteira
    ellipse(this.x + this.largura * 0.75, this.y + this.altura, 20, 20); // Roda traseira

    if (this.x < width / 2) {
      fill(50, 180, 50); // Verde
      rect(this.x + this.largura * 0.4, this.y - 10, 10, 15);
    } else {
      fill(200); // Branco
      rect(this.x + this.largura * 0.4, this.y - 10, 10, 15);
    }
  }
}

// --- CLASSE ÁRVORE (SEM MUDANÇAS AQUI NESTE TRECHO) ---
class Arvore {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.troncoAltura = random(40, 70);
    this.troncoLargura = random(8, 15);
    this.copaRaio = random(25, 40);
  }

  display() {
    noStroke();
    fill(139, 69, 19); // Marrom
    rect(this.x, this.y, this.troncoLargura, this.troncoAltura);

    fill(34, 139, 34); // Verde floresta
    ellipse(this.x + this.troncoLargura / 2, this.y, this.copaRaio * 1.5, this.copaRaio * 1.8);
    ellipse(this.x + this.troncoLargura / 2 - this.copaRaio * 0.3, this.y + this.copaRaio * 0.5, this.copaRaio * 1.2, this.copaRaio * 1.2);
    ellipse(this.x + this.troncoLargura / 2 + this.copaRaio * 0.3, this.y + this.copaRaio * 0.5, this.copaRaio * 1.2, this.copaRaio * 1.2);
  }
}

// --- CLASSE PRÉDIO (SEM MUDANÇAS AQUI NESTE TRECHO) ---
class Predio {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.largura = random(40, 80);
    this.altura = random(80, 180);
    this.cor = color(random(80, 150), random(80, 150), random(80, 150)); // Tons de cinza variados
    this.numJanelasX = floor(this.largura / 20); // Janelas horizontais
    this.numJanelasY = floor(this.altura / 30); // Janelas verticais
  }

  display() {
    noStroke();
    fill(this.cor);
    rect(this.x, this.y, this.largura, this.altura);

    fill(200, 200, 0, 180); // Amarelo claro semi-transparente para as janelas acesas
    let margemJanela = 5;
    let larguraJanela = (this.largura - margemJanela * (this.numJanelasX + 1)) / this.numJanelasX;
    let alturaJanela = (this.altura - margemJanela * (this.numJanelasY + 1)) / this.numJanelasY;

    for (let i = 0; i < this.numJanelasX; i++) {
      for (let j = 0; j < this.numJanelasY; j++) {
        rect(
          this.x + margemJanela + i * (larguraJanela + margemJanela),
          this.y + margemJanela + j * (alturaJanela + margemJanela),
          larguraJanela,
          alturaJanela
        );
      }
    }
  }
}

// --- CLASSE PARTICULAFUMACA (NOVA) ---
class ParticulaFumaca {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.tamanho = random(10, 25);
    this.velocidadeY = random(-0.5, -1.5); // Fumaça sobe
    this.velocidadeX = random(-0.2, 0.2); // Fumaça se move levemente para os lados
    this.alpha = 200; // Opacidade inicial
    this.reducaoAlpha = random(1, 3); // Taxa de desaparecimento
  }

  update() {
    this.x += this.velocidadeX;
    this.y += this.velocidadeY;
    this.alpha -= this.reducaoAlpha; // Diminui a opacidade
    this.tamanho += 0.2; // Aumenta o tamanho da fumaça levemente ao subir
  }

  display() {
    noStroke();
    fill(100, 100, 100, this.alpha); // Cor cinza com opacidade variável
    ellipse(this.x, this.y, this.tamanho, this.tamanho);
  }

  isFinished() {
    return this.alpha < 0; // Retorna true se a fumaça já desapareceu
  }
}

// --- FUNÇÃO desenhaFundo (SEM MUDANÇAS AQUI NESTE TRECHO) ---
function desenhaFundo() {
  for (let i = 0; i < width; i++) {
    let rCampo = map(i, 0, width / 2, 80, 20);
    let gCampo = map(i, 0, width / 2, 120, 30);
    let bCampo = map(i, 0, width / 2, 60, 10);
    let corCampo = color(rCampo, gCampo, bCampo);

    let rCidade = map(i, width / 2, width, 50, 100);
    let gCidade = map(i, width / 2, width, 50, 100);
    let bCidade = map(i, width / 2, width, 80, 150);
    let corCidade = color(rCidade, gCidade, bCidade);

    let interCor;
    if (i < width / 2) {
      interCor = lerpColor(color(80, 120, 60), color(20, 30, 10), map(i, 0, width / 2, 0, 1));
    } else {
      interCor = lerpColor(color(50, 50, 80), color(100, 100, 150), map(i, width / 2, width, 0, 1));
    }
    stroke(interCor);
    line(i, 0, i, height);
  }
}

function mousePressed() {
  // Você pode adicionar interações aqui
}